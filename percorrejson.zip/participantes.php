<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
//$q = intval($_GET['q']);

$con = mysqli_connect('localhost','root','','my_db');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"ajax_demo");
/*mostra cada chamada da tabela*/
//$sql="SELECT * FROM ajax_demo WHERE id = '".$q."'";

/*solicita as colunas*/
$sql = "SELECT  nome, idade FROM ajax_demo WHERE  id BETWEEN 1 AND 7 ORDER BY idade, nome"; 

/*mostra toda tabela*/
//$sql = "SELECT id, nome, idade, escolaridade, hobby FROM ajax_demo";
$result = mysqli_query($con,$sql);

echo "<table>
<tr>
<th>Nome</th>
<th>Idade</th>

</tr>";
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['nome'] . "</td>";
    echo "<td>" . $row['idade'] . "</td>";
    
    echo "</tr>";
}
echo "</table>";
mysqli_close($con);
?>
    <h3>Faixa etária</h3>
<p>São 7 participante dentre a faixa etária de: 0-10:1;  De 21-30:2;  De 31-40:2; De 51-60:1; De 61-70:1. </p>

<a href="../percorrejson/selecao.php">
    <input type="submit" value="Voltar" name="Voltar" />
</a>
</body>
</html>