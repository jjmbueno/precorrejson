<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
//$q = intval($_GET['q']);

$con = mysqli_connect('localhost','root','','my_db');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"ajax_demo");
/*mostra cada chamada da tabela*/
//$sql="SELECT * FROM ajax_demo WHERE id = '".$q."'";

/*solicita as colunas*/
$sql = "SELECT  nome, hobby FROM ajax_demo WHERE  id BETWEEN 1 AND 7 ORDER BY hobby, nome"; 

/*mostra toda tabela*/
//$sql = "SELECT id, nome, idade, escolaridade, hobby FROM ajax_demo";
$result = mysqli_query($con,$sql);

echo "<table>
<tr>
<th>Nome</th>
<th>Hobby</th>

</tr>";
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['nome'] . "</td>";
    echo "<td>" . $row['hobby'] . "</td>";
    echo "</tr>";
}
echo "</table>";
mysqli_close($con);
?>
    <h3>Hobbies citado</h3>
<p>Artesanato:1 Futebol:3 Jardinagem:1 Musica:2 Total de hobbies:4</p>

<a href="../percorrejson/selecao.php">
    <input type="submit" value="Voltar" name="Voltar" />
</a>
</body>
</html>