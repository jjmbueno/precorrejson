-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 02-Maio-2019 às 00:15
-- Versão do servidor: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_db`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `ajax_demo`
--

CREATE TABLE `ajax_demo` (
  `id` int(10) DEFAULT NULL,
  `nome` text NOT NULL,
  `idade` int(10) NOT NULL,
  `escolaridade` text NOT NULL,
  `hobby` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `ajax_demo`
--

INSERT INTO `ajax_demo` (`id`, `nome`, `idade`, `escolaridade`, `hobby`) VALUES
(1, 'João ', 53, 'medio completo', 'futebol'),
(2, 'Giovana\r\n', 20, 'superior cursando', 'artesanato'),
(3, 'Henrique', 22, 'superior cursando', 'futebol'),
(4, 'Manoel', 35, 'medio completo', 'musica'),
(5, 'Jessica', 40, 'medio completo', 'jardinagem'),
(6, 'Orfelia', 62, 'medio completo', 'musica'),
(7, 'Artur', 8, 'fundamental cursando', 'futebol');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
