<html>
<head>
<script>
function showUser(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","percorre.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
</head>
<body>

<h2>Resposta das questões</h2>
<h3>Clique para ver a resposta.</h3>

<p><a href="hobby.php">1-Quais hobbies foram citados? E quantas vezes?</a></p>    

<p><a href="participantes.php">2-Quantos participantes estão nas faixas etárias de 0-10, 11-20, 21-30,... anos?</a></p>

<p><a href="escolaridade.php">3-Quais níveis de escolaridade foram citados? E quantas vezes?</a></p>
<hr>
<h2>Encontre por indivíduo</h2>
<form>
<select name="users" onchange="showUser(this.value)">
  <option value="">Selecione um nome:</option>
  <option value="1">João</option>
  <option value="2">Giovana</option>
  <option value="3">Henrique</option>
  <option value="4">Manoel</option>
  <option value="5">Jessica</option>
  <option value="6">Orfelia</option>
  <option value="7">Artur</option>
  </select>
</form>
<br>
<div id="txtHint"><b>Informe uma das opções...</b></div>
<hr>
<h2>Código disponível no link abaixo</h2>
<a href="">Ver o código.</a>
</body>
</html>


